<div align="center">

<img src="https://readme-typing-svg.demolab.com?font=Fira+Code&size=28&duration=3000&pause=800&color=F7931E&center=true&vCenter=true&width=600&lines=Hi+there%2C+I'm+Santhosh+Kumar+%F0%9F%91%8B;Full+Stack+Developer;Data+Science+Enthusiast;CS+Student+%40+VIT-AP+University" alt="Typing SVG" />

</div>

<br/>

<div align="center">
  <img src="https://komarev.com/ghpvc/?username=santhoshkumar&color=f7931e&style=flat-square&label=Profile+Views" alt="profile views" />
  <img src="https://img.shields.io/github/followers/santhoshkumar?label=Followers&style=flat-square&color=f7931e" alt="followers" />
</div>

## 🚀 About Me

- 🎓 Computer Science student at **VIT-AP University**, focused on **Data Science**
- 💻 MERN Full Stack Developer — Java, React.js, Node.js, MongoDB
- 🧠 Interested in Deep Learning & applied ML research
- 🛠️ Currently building a **Ticket Booking System** (seat holds, concurrency, waitlists, QR tickets)
- 🌱 Completed internships at **Prodigy InfoTech** and **Six Phrase**
- 📫 Reach me at: your-email@example.com

## 🧰 Tech Stack

<div align="center">

<img src="https://skillicons.dev/icons?i=java,js,react,nodejs,express,mongodb,mysql,py,html,css,git,figma&theme=dark" alt="skills"/>

</div>

## 📊 GitHub Stats

<div align="center">

<img src="https://github-readme-stats.vercel.app/api?username=santhoshkumar&show_icons=true&theme=radical&hide_border=true&count_private=true" alt="stats" width="48%"/>
<img src="https://github-readme-stats.vercel.app/api/top-langs/?username=santhoshkumar&layout=compact&theme=radical&hide_border=true" alt="top languages" width="38%"/>

</div>

<div align="center">

<img src="https://github-readme-streak-stats.herokuapp.com/?user=santhoshkumar&theme=radical&hide_border=true" alt="streak stats"/>

</div>

## 🐍 Contribution Graph

<div align="center">

<img src="https://raw.githubusercontent.com/santhoshkumar/santhoshkumar/output/github-contribution-grid-snake.svg" alt="snake animation"/>

</div>

## 🔗 Connect with Me

<div align="center">

<a href="https://linkedin.com/in/santhoshkumar" target="_blank">
  <img src="https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn"/>
</a>
<a href="mailto:your-email@example.com">
  <img src="https://img.shields.io/badge/Email-D14836?style=for-the-badge&logo=gmail&logoColor=white" alt="Email"/>
</a>
<a href="https://your-portfolio-url.com" target="_blank">
  <img src="https://img.shields.io/badge/Portfolio-000000?style=for-the-badge&logo=vercel&logoColor=white" alt="Portfolio"/>
</a>

</div>

<div align="center">
<sub>⭐️ From <b>santhoshkumar</b> — thanks for stopping by!</sub>
</div>
